#ifndef _CATIN_TYPES_H
#define _CATIN_TYPES_H
typedef unsigned char       u8;
typedef unsigned short      u16;
typedef unsigned int        u32;
typedef unsigned long long  u64;
typedef signed char         s8;
typedef signed short        s16;
typedef signed int          s32;
typedef signed long long    s64;
typedef u64                 usize;
typedef s64                 isize;
#define NULL ((void*)0)
#define true  1
#define false 0
typedef int bool;
#endif
